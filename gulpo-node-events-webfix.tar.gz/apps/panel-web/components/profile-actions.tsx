"use client";

import { useState } from "react";

type Props = {
  clientPassword: string;
  ssURI: string;
};

export function ProfileActions({ clientPassword, ssURI }: Props) {
  const [notice, setNotice] = useState("");

  async function copy(value: string, label: string) {
    try {
      await navigator.clipboard.writeText(value);
      setNotice(`${label} copied`);
      window.setTimeout(() => setNotice(""), 1600);
    } catch {
      setNotice(`Could not copy ${label.toLowerCase()}`);
    }
  }

  return (
    <div className="profile-actions">
      <div className="actions-row">
        <button className="secondary" onClick={() => void copy(clientPassword, "Password")} type="button">
          Copy Password
        </button>
        <button className="secondary" onClick={() => void copy(ssURI, "ss:// profile")} type="button">
          Copy ss://
        </button>
      </div>
      {notice ? <div className="notice compact-notice">{notice}</div> : null}
    </div>
  );
}
