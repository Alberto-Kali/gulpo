export type ProfileItem = {
  node_id: string;
  name: string;
  server: string;
  port: number;
  method: string;
  client_password: string;
  password_masked: string;
  ss_uri: string;
  last_seen_at?: string | null;
  status: string;
};

export type ProfilePageResponse = {
  user_name: string;
  user_status: string;
  subscription_token: string;
  profiles: ProfileItem[];
  message?: string;
};

function getInternalAPIBase() {
  return process.env.PANEL_API_INTERNAL_BASE_URL || "http://localhost:8080";
}

export async function getSubjProfiles(token: string): Promise<{ data?: ProfilePageResponse; error?: string; status: number }> {
  const response = await fetch(`${getInternalAPIBase()}/api/subj/${token}`, {
    cache: "no-store",
  });

  if (!response.ok) {
    let error = response.statusText;
    try {
      const body = await response.json();
      error = body.error ?? error;
    } catch {}
    return { error, status: response.status };
  }

  return {
    data: await response.json(),
    status: response.status,
  };
}
