import { ProfileActions } from "../../../components/profile-actions";
import { getSubjProfiles } from "../../../lib/server-api";

export const dynamic = "force-dynamic";

export default async function SubjPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const result = await getSubjProfiles(token);

  if (!result.data) {
    return (
      <main className="page">
        <div className="shell">
          <section className="hero client-hero">
            <div className="meta">
              <span className="pill warn">Unavailable</span>
              <span className="pill subtle">/subj</span>
            </div>
            <h1>Profile list unavailable</h1>
            <p>{result.error ?? "The subscription token could not be resolved."}</p>
          </section>
        </div>
      </main>
    );
  }

  const { data } = result;

  return (
    <main className="page">
      <div className="shell">
        <section className="hero client-hero">
          <div className="meta">
            <span className="pill">Happ</span>
            <span className="pill">Shadowsocks</span>
            <span className="pill subtle">{data.user_status}</span>
          </div>
          <h1>{data.user_name || "Subscription Profiles"}</h1>
          <p>
            Use these Shadowsocks profiles to connect Happ to one of your available nodes.
            Copy the full <code>ss://</code> URI or just the password when needed.
          </p>
        </section>

        <section className="panel panel-span-3">
          <div className="section-head">
            <div>
              <h2>Available Profiles</h2>
              <p className="section-copy">Token: <span className="wrap-anywhere token-inline">{data.subscription_token}</span></p>
            </div>
          </div>

          {data.message ? <div className="notice">{data.message}</div> : null}

          <div className="card-list subj-list">
            {data.profiles.map((profile) => (
              <article className="card profile-card" key={`${profile.node_id}-${profile.port}`}>
                <div className="profile-main">
                  <div className="meta">
                    <span className="pill">{profile.status}</span>
                    <span className="pill subtle">{profile.method}</span>
                    <span className="pill subtle">{profile.port}</span>
                  </div>
                  <h3>{profile.name}</h3>
                  <div className="profile-grid">
                    <div className="field-readonly">
                      <span>Server</span>
                      <strong className="wrap-anywhere">{profile.server}</strong>
                    </div>
                    <div className="field-readonly">
                      <span>Password</span>
                      <strong className="wrap-anywhere">{profile.password_masked}</strong>
                    </div>
                  </div>
                  <div className="field-readonly">
                    <span>ss:// profile</span>
                    <code className="token-box wrap-anywhere">{profile.ss_uri}</code>
                  </div>
                </div>
                <ProfileActions clientPassword={profile.client_password} ssURI={profile.ss_uri} />
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
