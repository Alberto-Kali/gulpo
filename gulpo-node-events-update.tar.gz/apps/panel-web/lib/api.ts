function resolveApiBase() {
  if (process.env.NEXT_PUBLIC_PANEL_API_BASE_URL) {
    return process.env.NEXT_PUBLIC_PANEL_API_BASE_URL;
  }
  if (typeof window !== "undefined") {
    return `${window.location.protocol}//${window.location.hostname}:8080`;
  }
  return "http://localhost:8080";
}

const API_BASE = resolveApiBase();

async function parse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let message = response.statusText;
    try {
      const body = await response.json();
      message = body.error ?? message;
    } catch {}
    throw new Error(message);
  }
  if (response.status === 204) {
    return undefined as T;
  }
  return response.json();
}

type Tag = {
  id: string;
  name: string;
};

export type User = {
  id: string;
  external_id?: string | null;
  name: string;
  status: string;
  traffic_limit_bytes: number;
  traffic_used_bytes: number;
  subscription_token: string;
  node_access_mode: string;
  tags?: Tag[] | null;
  allowed_node_ids?: string[] | null;
};

export type Node = {
  id: string;
  name: string;
  domain: string;
  status: string;
  default_access_policy: string;
  default_access_tag?: string | null;
  agent_version?: string;
  singbox_version?: string;
  last_seen_at?: string | null;
};

export type NodeEvent = {
  id: string;
  node_id: string;
  level: string;
  type: string;
  message: string;
  source: string;
  created_at: string;
};

function normalizeUser(user: User): User {
  return {
    ...user,
    external_id: user.external_id ?? null,
    tags: Array.isArray(user.tags) ? user.tags : [],
    allowed_node_ids: Array.isArray(user.allowed_node_ids) ? user.allowed_node_ids : [],
  };
}

function normalizeNode(node: Node): Node {
  return {
    ...node,
    default_access_tag: node.default_access_tag ?? null,
    last_seen_at: node.last_seen_at ?? null,
    agent_version: node.agent_version ?? "",
    singbox_version: node.singbox_version ?? "",
  };
}

export async function login(email: string, password: string) {
  return parse<{ token: string }>(
    await fetch(`${API_BASE}/api/admin/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    }),
  );
}

export async function listUsers(token: string) {
  const data = await parse<User[] | null>(
    await fetch(`${API_BASE}/api/admin/users`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }),
  );
  return (Array.isArray(data) ? data : []).map(normalizeUser);
}

export async function createUser(token: string, payload: Record<string, unknown>) {
  return normalizeUser(
    await parse<User>(
      await fetch(`${API_BASE}/api/admin/users`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }),
    ),
  );
}

export async function updateUser(token: string, userId: string, payload: Record<string, unknown>) {
  return normalizeUser(
    await parse<User>(
      await fetch(`${API_BASE}/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }),
    ),
  );
}

export async function deleteUser(token: string, userId: string) {
  await parse<unknown>(
    await fetch(`${API_BASE}/api/admin/users/${userId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }),
  );
}

export async function updateUserTags(token: string, userId: string, tags: string[]) {
  return parse<Tag[]>(
    await fetch(`${API_BASE}/api/admin/users/${userId}/tags`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ tags }),
    }),
  );
}

export async function rotateUserSubscription(token: string, userId: string) {
  return parse<{ subscription_token: string }>(
    await fetch(`${API_BASE}/api/admin/users/${userId}/subscription/rotate`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }),
  );
}

export async function listNodes(token: string) {
  const data = await parse<Node[] | null>(
    await fetch(`${API_BASE}/api/admin/nodes`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }),
  );
  return (Array.isArray(data) ? data : []).map(normalizeNode);
}

export async function createNode(token: string, payload: Record<string, unknown>) {
  return normalizeNode(
    await parse<Node>(
      await fetch(`${API_BASE}/api/admin/nodes`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }),
    ),
  );
}

export async function updateNode(token: string, nodeId: string, payload: Record<string, unknown>) {
  return normalizeNode(
    await parse<Node>(
      await fetch(`${API_BASE}/api/admin/nodes/${nodeId}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }),
    ),
  );
}

export async function deleteNode(token: string, nodeId: string) {
  await parse<unknown>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }),
  );
}

export async function rotateNodeEnrollToken(token: string, nodeId: string) {
  return parse<{ enroll_token: string }>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}/enroll-token/rotate`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }),
  );
}

export async function sendNodeCommand(token: string, nodeId: string, type: string, payload: Record<string, unknown> = {}) {
  return parse<{ id: string; status: string }>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}/commands`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ type, payload }),
    }),
  );
}

export async function getNodeConfig(token: string, nodeId: string) {
  return parse<Record<string, unknown>>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}/config`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }),
  );
}

export async function listNodeEvents(token: string, nodeId: string, limit = 100) {
  return parse<NodeEvent[]>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}/events?limit=${limit}`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }),
  );
}

export async function updateNodeConfig(token: string, nodeId: string, payload: Record<string, unknown>) {
  return parse<{ status: string }>(
    await fetch(`${API_BASE}/api/admin/nodes/${nodeId}/config`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }),
  );
}

export async function getGlobalConfig(token: string) {
  return parse<Record<string, unknown>>(
    await fetch(`${API_BASE}/api/admin/config/global`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }),
  );
}

export async function updateGlobalConfig(token: string, payload: Record<string, unknown>) {
  return parse<Record<string, unknown>>(
    await fetch(`${API_BASE}/api/admin/config/global`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }),
  );
}
