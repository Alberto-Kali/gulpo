"use client";

import { FormEvent, useEffect, useState } from "react";
import {
  createNode,
  createUser,
  deleteNode,
  deleteUser,
  getGlobalConfig,
  getNodeConfig,
  listNodes,
  listNodeEvents,
  listUsers,
  login,
  Node,
  NodeEvent,
  rotateNodeEnrollToken,
  rotateUserSubscription,
  sendNodeCommand,
  updateGlobalConfig,
  updateNode,
  updateNodeConfig,
  updateUser,
  updateUserTags,
  User,
} from "../lib/api";

type Props = {
  defaultEmail: string;
};

type UserForm = {
  externalID: string;
  name: string;
  status: string;
  trafficLimitBytes: string;
  nodeAccessMode: string;
  tagsText: string;
  allowedNodeIDs: string[];
};

type NodeForm = {
  name: string;
  domain: string;
  status: string;
  defaultAccessPolicy: string;
  defaultAccessTag: string;
};

const initialConfig = {
  log: { level: "info" },
  outbounds: [],
  route: { final: "direct" },
};

function tagsToText(tags: User["tags"]) {
  return (tags ?? []).map((tag) => tag.name).join(", ");
}

function buildUserForm(user: User): UserForm {
  return {
    externalID: user.external_id ?? "",
    name: user.name,
    status: user.status,
    trafficLimitBytes: String(user.traffic_limit_bytes ?? 0),
    nodeAccessMode: user.node_access_mode || "tags",
    tagsText: tagsToText(user.tags),
    allowedNodeIDs: Array.isArray(user.allowed_node_ids) ? user.allowed_node_ids : [],
  };
}

function buildNodeForm(node: Node): NodeForm {
  return {
    name: node.name,
    domain: node.domain,
    status: node.status,
    defaultAccessPolicy: node.default_access_policy,
    defaultAccessTag: node.default_access_tag ?? "",
  };
}

export function Dashboard({ defaultEmail }: Props) {
  const [token, setToken] = useState<string>("");
  const [email, setEmail] = useState(defaultEmail);
  const [password, setPassword] = useState("change-me");
  const [users, setUsers] = useState<User[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [configText, setConfigText] = useState(JSON.stringify(initialConfig, null, 2));
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [userDialog, setUserDialog] = useState<User | null>(null);
  const [userForm, setUserForm] = useState<UserForm | null>(null);
  const [userDialogBusy, setUserDialogBusy] = useState(false);
  const [userDialogNotice, setUserDialogNotice] = useState("");
  const [nodeDialog, setNodeDialog] = useState<Node | null>(null);
  const [nodeForm, setNodeForm] = useState<NodeForm | null>(null);
  const [nodeConfigText, setNodeConfigText] = useState("{}");
  const [nodeEvents, setNodeEvents] = useState<NodeEvent[]>([]);
  const [nodeDialogBusy, setNodeDialogBusy] = useState(false);
  const [nodeDialogNotice, setNodeDialogNotice] = useState("");

  useEffect(() => {
    if (!token) return;
    void refresh(token);
  }, [token]);

  async function refresh(authToken: string) {
    try {
      const [userList, nodeList, globalConfig] = await Promise.all([
        listUsers(authToken),
        listNodes(authToken),
        getGlobalConfig(authToken),
      ]);
      setUsers(userList);
      setNodes(nodeList);
      setConfigText(JSON.stringify(globalConfig, null, 2));
      if (nodeDialog) {
        await refreshNodeDialogData(nodeDialog.id, authToken);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load dashboard");
    }
  }

  async function onLogin(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await login(email, password);
      setToken(response.token);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setBusy(false);
    }
  }

  async function onCreateUser() {
    if (!token) return;
    setBusy(true);
    setError("");
    try {
      await createUser(token, {
        name: `user-${users.length + 1}`,
        status: "active",
        traffic_limit_bytes: 10737418240,
        node_access_mode: "tags",
        tags: ["default"],
      });
      await refresh(token);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create user");
    } finally {
      setBusy(false);
    }
  }

  async function onCreateNode() {
    if (!token) return;
    setBusy(true);
    setError("");
    try {
      await createNode(token, {
        name: `node-${nodes.length + 1}`,
        domain: `node-${nodes.length + 1}.example.com`,
        status: "pending",
        default_access_policy: "tag",
        default_access_tag: "default",
        agent_version: "",
        singbox_version: "",
      });
      await refresh(token);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create node");
    } finally {
      setBusy(false);
    }
  }

  async function onSaveConfig() {
    if (!token) return;
    setBusy(true);
    setError("");
    try {
      await updateGlobalConfig(token, JSON.parse(configText));
      await refresh(token);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save config");
    } finally {
      setBusy(false);
    }
  }

  function openUserDialog(user: User) {
    setUserDialog(user);
    setUserForm(buildUserForm(user));
    setUserDialogNotice("");
  }

  async function openNodeDialog(node: Node) {
    setNodeDialog(node);
    setNodeForm(buildNodeForm(node));
    setNodeDialogNotice("");
    setNodeConfigText("{}");
    setNodeEvents([]);
    if (!token) return;
    setNodeDialogBusy(true);
    try {
      const [config, events] = await Promise.all([
        getNodeConfig(token, node.id),
        listNodeEvents(token, node.id, 100),
      ]);
      setNodeConfigText(JSON.stringify(config, null, 2));
      setNodeEvents(events);
    } catch (err) {
      setNodeDialogNotice(err instanceof Error ? err.message : "Could not load node config");
    } finally {
      setNodeDialogBusy(false);
    }
  }

  function closeUserDialog() {
    setUserDialog(null);
    setUserForm(null);
    setUserDialogBusy(false);
    setUserDialogNotice("");
  }

  function closeNodeDialog() {
    setNodeDialog(null);
    setNodeForm(null);
    setNodeConfigText("{}");
    setNodeEvents([]);
    setNodeDialogBusy(false);
    setNodeDialogNotice("");
  }

  async function refreshNodeDialogData(nodeId: string, authToken: string) {
    const [config, events] = await Promise.all([
      getNodeConfig(authToken, nodeId),
      listNodeEvents(authToken, nodeId, 100),
    ]);
    setNodeConfigText(JSON.stringify(config, null, 2));
    setNodeEvents(events);
  }

  async function submitUserDialog() {
    if (!token || !userDialog || !userForm) return;
    setUserDialogBusy(true);
    setUserDialogNotice("");
    try {
      const updatedUser = await updateUser(token, userDialog.id, {
        external_id: userForm.externalID || null,
        name: userForm.name,
        status: userForm.status,
        traffic_limit_bytes: Number(userForm.trafficLimitBytes) || 0,
        node_access_mode: userForm.nodeAccessMode,
        allowed_node_ids: userForm.nodeAccessMode === "explicit" ? userForm.allowedNodeIDs : [],
      });
      await updateUserTags(
        token,
        userDialog.id,
        userForm.tagsText
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean),
      );
      await refresh(token);
      const freshUser = users.find((item) => item.id === updatedUser.id);
      setUserDialog(freshUser ?? updatedUser);
      setUserForm(buildUserForm(freshUser ?? updatedUser));
      setUserDialogNotice("User updated.");
    } catch (err) {
      setUserDialogNotice(err instanceof Error ? err.message : "Could not update user");
    } finally {
      setUserDialogBusy(false);
    }
  }

  async function rotateSubscription() {
    if (!token || !userDialog) return;
    setUserDialogBusy(true);
    setUserDialogNotice("");
    try {
      const result = await rotateUserSubscription(token, userDialog.id);
      await refresh(token);
      setUserDialog({
        ...userDialog,
        subscription_token: result.subscription_token,
      });
      setUserDialogNotice("Subscription token rotated.");
    } catch (err) {
      setUserDialogNotice(err instanceof Error ? err.message : "Could not rotate subscription token");
    } finally {
      setUserDialogBusy(false);
    }
  }

  async function submitNodeDialog() {
    if (!token || !nodeDialog || !nodeForm) return;
    setNodeDialogBusy(true);
    setNodeDialogNotice("");
    try {
      const updatedNode = await updateNode(token, nodeDialog.id, {
        name: nodeForm.name,
        domain: nodeForm.domain,
        status: nodeForm.status,
        default_access_policy: nodeForm.defaultAccessPolicy,
        default_access_tag: nodeForm.defaultAccessPolicy === "tag" ? nodeForm.defaultAccessTag || null : null,
        agent_version: nodeDialog.agent_version ?? "",
        singbox_version: nodeDialog.singbox_version ?? "",
      });
      await updateNodeConfig(token, nodeDialog.id, JSON.parse(nodeConfigText));
      await refresh(token);
      await refreshNodeDialogData(nodeDialog.id, token);
      setNodeDialog(updatedNode);
      setNodeForm(buildNodeForm(updatedNode));
      setNodeDialogNotice("Node and node-local config updated.");
    } catch (err) {
      setNodeDialogNotice(err instanceof Error ? err.message : "Could not update node");
    } finally {
      setNodeDialogBusy(false);
    }
  }

  async function rotateEnrollToken() {
    if (!token || !nodeDialog) return;
    setNodeDialogBusy(true);
    setNodeDialogNotice("");
    try {
      const result = await rotateNodeEnrollToken(token, nodeDialog.id);
      setNodeDialogNotice(`New enroll token: ${result.enroll_token}`);
    } catch (err) {
      setNodeDialogNotice(err instanceof Error ? err.message : "Could not rotate enroll token");
    } finally {
      setNodeDialogBusy(false);
    }
  }

  async function runNodeCommand(type: "ping" | "reload" | "restart") {
    if (!token || !nodeDialog) return;
    setNodeDialogBusy(true);
    setNodeDialogNotice("");
    try {
      await sendNodeCommand(token, nodeDialog.id, type, {});
      await refreshNodeDialogData(nodeDialog.id, token);
      setNodeDialogNotice(`Command queued: ${type}.`);
    } catch (err) {
      setNodeDialogNotice(err instanceof Error ? err.message : `Could not queue ${type}`);
    } finally {
      setNodeDialogBusy(false);
    }
  }

  async function removeUser() {
    if (!token || !userDialog) return;
    if (!window.confirm(`Delete user "${userDialog.name}" permanently?`)) return;
    setUserDialogBusy(true);
    setUserDialogNotice("");
    try {
      await deleteUser(token, userDialog.id);
      closeUserDialog();
      await refresh(token);
    } catch (err) {
      setUserDialogNotice(err instanceof Error ? err.message : "Could not delete user");
    } finally {
      setUserDialogBusy(false);
    }
  }

  async function removeNode() {
    if (!token || !nodeDialog) return;
    if (!window.confirm(`Delete node "${nodeDialog.name}" permanently?`)) return;
    setNodeDialogBusy(true);
    setNodeDialogNotice("");
    try {
      await deleteNode(token, nodeDialog.id);
      closeNodeDialog();
      await refresh(token);
    } catch (err) {
      setNodeDialogNotice(err instanceof Error ? err.message : "Could not delete node");
    } finally {
      setNodeDialogBusy(false);
    }
  }

  if (!token) {
    return (
      <section className="panel login-panel">
        <h2>Admin Login</h2>
        <form className="form" onSubmit={onLogin}>
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" />
          <button disabled={busy} type="submit">
            {busy ? "Signing in..." : "Sign in"}
          </button>
          {error ? <div className="pill warn">{error}</div> : null}
        </form>
      </section>
    );
  }

  return (
    <>
      <div className="dashboard-grid">
        <section className="panel panel-span-2">
          <div className="section-head">
            <div>
              <h2>Users</h2>
              <p className="section-copy">Traffic, tags, node access and subscription lifecycle in one place.</p>
            </div>
            <div className="toolbar">
              <button onClick={onCreateUser} disabled={busy}>Create Demo User</button>
              <button className="secondary" onClick={() => void refresh(token)} disabled={busy}>Refresh</button>
            </div>
          </div>
          <div className="card-list">
            {users.length === 0 ? <div className="empty-state">No users yet.</div> : null}
            {users.map((user) => (
              <article className="card card-grid" key={user.id}>
                <div className="card-main">
                  <div className="meta">
                    <span className="pill">{user.status}</span>
                    <span className="pill subtle">{user.node_access_mode}</span>
                    <span className="muted-text wrap-anywhere">
                      {user.traffic_used_bytes} / {user.traffic_limit_bytes} bytes
                    </span>
                  </div>
                  <h3>{user.name}</h3>
                  <p className="muted-text wrap-anywhere">
                    External ID: {user.external_id || "none"}
                  </p>
                  <p className="token-text wrap-anywhere">
                    Subscription token: <code>{user.subscription_token}</code>
                  </p>
                  <a className="inline-link wrap-anywhere" href={`/subj/${user.subscription_token}`} target="_blank" rel="noreferrer">
                    Open /subj/{user.subscription_token}
                  </a>
                  <div className="meta">
                    {(user.tags ?? []).map((tag) => (
                      <span className="pill" key={tag.id}>{tag.name}</span>
                    ))}
                  </div>
                </div>
                <div className="card-actions">
                  <button className="secondary" onClick={() => openUserDialog(user)}>Edit User</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="section-head">
            <div>
              <h2>Nodes</h2>
              <p className="section-copy">Manage domains, access policy and runtime operations.</p>
            </div>
            <div className="toolbar">
              <button onClick={onCreateNode} disabled={busy}>Create Demo Node</button>
            </div>
          </div>
          <div className="card-list">
            {nodes.length === 0 ? <div className="empty-state">No nodes yet.</div> : null}
            {nodes.map((node) => (
              <article className="card card-grid" key={node.id}>
                <div className="card-main">
                  <div className="meta">
                    <span className="pill">{node.status}</span>
                    <span className="pill subtle">{node.default_access_policy}</span>
                  </div>
                  <h3>{node.name}</h3>
                  <p className="token-text wrap-anywhere">{node.domain}</p>
                  <div className="stack compact-stack">
                    <span className="muted-text">Last seen: {node.last_seen_at ?? "never"}</span>
                    <span className="muted-text">Agent: {node.agent_version || "unknown"}</span>
                    <span className="muted-text">Sing-box: {node.singbox_version || "unknown"}</span>
                  </div>
                </div>
                <div className="card-actions">
                  <button className="secondary" onClick={() => void openNodeDialog(node)}>Edit Node</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel panel-span-3">
          <div className="section-head">
            <div>
              <h2>Global Node Config</h2>
              <p className="section-copy">Shared base config for routing, outbounds and defaults. Keep node-specific inbounds, ports and ACME in each node config.</p>
            </div>
          </div>
          <div className="form">
            <textarea className="config-editor" value={configText} onChange={(e) => setConfigText(e.target.value)} />
            <div className="actions-row">
              <button onClick={onSaveConfig} disabled={busy}>Save Global Config</button>
              {error ? <div className="pill warn">{error}</div> : null}
            </div>
          </div>
        </section>
      </div>

      {userDialog && userForm ? (
        <div className="overlay" onClick={closeUserDialog}>
          <section className="dialog" onClick={(event) => event.stopPropagation()}>
            <div className="dialog-head">
              <div>
                <h2>Edit User</h2>
                <p className="section-copy">Update identity, limits, tags and node access rules.</p>
              </div>
              <button className="secondary" onClick={closeUserDialog}>Close</button>
            </div>
            <div className="dialog-body">
              <div className="split">
                <label className="field">
                  <span>Name</span>
                  <input value={userForm.name} onChange={(e) => setUserForm({ ...userForm, name: e.target.value })} />
                </label>
                <label className="field">
                  <span>External ID</span>
                  <input value={userForm.externalID} onChange={(e) => setUserForm({ ...userForm, externalID: e.target.value })} />
                </label>
              </div>
              <div className="split">
                <label className="field">
                  <span>Status</span>
                  <select value={userForm.status} onChange={(e) => setUserForm({ ...userForm, status: e.target.value })}>
                    <option value="active">active</option>
                    <option value="disabled">disabled</option>
                    <option value="expired">expired</option>
                  </select>
                </label>
                <label className="field">
                  <span>Traffic Limit Bytes</span>
                  <input value={userForm.trafficLimitBytes} onChange={(e) => setUserForm({ ...userForm, trafficLimitBytes: e.target.value })} inputMode="numeric" />
                </label>
              </div>
              <div className="split">
                <label className="field">
                  <span>Node Access Mode</span>
                  <select value={userForm.nodeAccessMode} onChange={(e) => setUserForm({ ...userForm, nodeAccessMode: e.target.value })}>
                    <option value="tags">tags</option>
                    <option value="explicit">explicit</option>
                  </select>
                </label>
                <label className="field">
                  <span>Tags</span>
                  <input
                    value={userForm.tagsText}
                    onChange={(e) => setUserForm({ ...userForm, tagsText: e.target.value })}
                    placeholder="default, beta"
                  />
                </label>
              </div>

              {userForm.nodeAccessMode === "explicit" ? (
                <div className="field">
                  <span>Allowed Nodes</span>
                  <div className="checkbox-list">
                    {nodes.map((node) => {
                      const checked = userForm.allowedNodeIDs.includes(node.id);
                      return (
                        <label className="check-row" key={node.id}>
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(e) => {
                              const next = e.target.checked
                                ? [...userForm.allowedNodeIDs, node.id]
                                : userForm.allowedNodeIDs.filter((value) => value !== node.id);
                              setUserForm({ ...userForm, allowedNodeIDs: next });
                            }}
                          />
                          <span className="wrap-anywhere">{node.name} ({node.domain})</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              <div className="field">
                <span>Current Subscription Token</span>
                <div className="token-box wrap-anywhere">
                  <code>{userDialog.subscription_token}</code>
                </div>
                <a className="inline-link wrap-anywhere" href={`/subj/${userDialog.subscription_token}`} target="_blank" rel="noreferrer">
                  Open /subj/{userDialog.subscription_token}
                </a>
              </div>
            </div>
            <div className="dialog-actions">
              <button className="danger" disabled={userDialogBusy} onClick={removeUser}>
                Delete User
              </button>
              <button className="secondary" disabled={userDialogBusy} onClick={rotateSubscription}>
                Rotate Subscription
              </button>
              <button disabled={userDialogBusy} onClick={() => void submitUserDialog()}>
                {userDialogBusy ? "Saving..." : "Save User"}
              </button>
            </div>
            {userDialogNotice ? <div className="notice">{userDialogNotice}</div> : null}
          </section>
        </div>
      ) : null}

      {nodeDialog && nodeForm ? (
        <div className="overlay" onClick={closeNodeDialog}>
          <section className="dialog" onClick={(event) => event.stopPropagation()}>
            <div className="dialog-head">
              <div>
                <h2>Edit Node</h2>
                <p className="section-copy">Update identity, access defaults and send runtime commands.</p>
              </div>
              <button className="secondary" onClick={closeNodeDialog}>Close</button>
            </div>
            <div className="dialog-body">
              <div className="split">
                <label className="field">
                  <span>Name</span>
                  <input value={nodeForm.name} onChange={(e) => setNodeForm({ ...nodeForm, name: e.target.value })} />
                </label>
                <label className="field">
                  <span>Domain</span>
                  <input value={nodeForm.domain} onChange={(e) => setNodeForm({ ...nodeForm, domain: e.target.value })} />
                </label>
              </div>
              <div className="split">
                <label className="field">
                  <span>Status</span>
                  <select value={nodeForm.status} onChange={(e) => setNodeForm({ ...nodeForm, status: e.target.value })}>
                    <option value="pending">pending</option>
                    <option value="online">online</option>
                    <option value="offline">offline</option>
                    <option value="disabled">disabled</option>
                  </select>
                </label>
                <label className="field">
                  <span>Default Access Policy</span>
                  <select
                    value={nodeForm.defaultAccessPolicy}
                    onChange={(e) => setNodeForm({ ...nodeForm, defaultAccessPolicy: e.target.value })}
                  >
                    <option value="tag">tag</option>
                    <option value="nobody">nobody</option>
                    <option value="open">open</option>
                  </select>
                </label>
              </div>
              {nodeForm.defaultAccessPolicy === "tag" ? (
                <label className="field">
                  <span>Default Access Tag</span>
                  <input value={nodeForm.defaultAccessTag} onChange={(e) => setNodeForm({ ...nodeForm, defaultAccessTag: e.target.value })} />
                </label>
              ) : null}
              <div className="split">
                <div className="stat-box">
                  <span className="muted-text">Last seen</span>
                  <strong>{nodeDialog.last_seen_at ?? "never"}</strong>
                </div>
                <div className="stat-box">
                  <span className="muted-text">Versions</span>
                  <strong>{nodeDialog.agent_version || "unknown"} / {nodeDialog.singbox_version || "unknown"}</strong>
                </div>
              </div>
              <div className="field">
                <span>Node Config</span>
                <textarea
                  className="config-editor"
                  value={nodeConfigText}
                  onChange={(e) => setNodeConfigText(e.target.value)}
                  placeholder={`{\n  "inbounds": [\n    {\n      "type": "shadowsocks",\n      "listen_port": 2080,\n      "method": "aes-128-gcm"\n    },\n    {\n      "type": "trojan",\n      "listen_port": 8443,\n      "tls": {\n        "enabled": true,\n        "acme": {\n          "enabled": true\n        }\n      }\n    }\n  ]\n}`}
                />
                <p className="muted-text wrap-anywhere">
                  Node-local config owns protocol inbounds, ports and TLS/ACME. Global config should stay focused on shared routing, outbounds and base defaults.
                </p>
              </div>
              <div className="field">
                <span>Recent Node Events</span>
                {nodeEvents.length === 0 ? (
                  <div className="empty-state">No node events yet.</div>
                ) : (
                  <div className="event-list">
                    {nodeEvents.map((event) => (
                      <article className="event-card" key={event.id}>
                        <div className="meta">
                          <span className={`pill ${event.level === "error" ? "warn" : event.level === "warn" ? "subtle" : ""}`}>
                            {event.type}
                          </span>
                          <span className="pill subtle">{event.source}</span>
                          <span className="muted-text wrap-anywhere">{event.created_at}</span>
                        </div>
                        <p className="muted-text wrap-anywhere">{event.message}</p>
                      </article>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="dialog-actions wrap-actions">
              <button className="danger" disabled={nodeDialogBusy} onClick={removeNode}>Delete Node</button>
              <button className="secondary" disabled={nodeDialogBusy} onClick={rotateEnrollToken}>Rotate Enroll Token</button>
              <button className="secondary" disabled={nodeDialogBusy} onClick={() => void runNodeCommand("ping")}>Ping</button>
              <button className="secondary" disabled={nodeDialogBusy} onClick={() => void runNodeCommand("reload")}>Reload</button>
              <button className="secondary" disabled={nodeDialogBusy} onClick={() => void runNodeCommand("restart")}>Restart</button>
              <button disabled={nodeDialogBusy} onClick={() => void submitNodeDialog()}>
                {nodeDialogBusy ? "Saving..." : "Save Node"}
              </button>
            </div>
            {nodeDialogNotice ? <div className="notice wrap-anywhere">{nodeDialogNotice}</div> : null}
          </section>
        </div>
      ) : null}
    </>
  );
}
