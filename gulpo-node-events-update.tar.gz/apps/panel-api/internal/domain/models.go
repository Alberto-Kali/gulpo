package domain

import (
	"encoding/json"
	"time"
)

type UserStatus string

const (
	UserStatusActive   UserStatus = "active"
	UserStatusDisabled UserStatus = "disabled"
	UserStatusExpired  UserStatus = "expired"
)

type NodeStatus string

const (
	NodeStatusPending  NodeStatus = "pending"
	NodeStatusOnline   NodeStatus = "online"
	NodeStatusOffline  NodeStatus = "offline"
	NodeStatusDisabled NodeStatus = "disabled"
)

type NodeAccessMode string

const (
	NodeAccessModeTags     NodeAccessMode = "tags"
	NodeAccessModeExplicit NodeAccessMode = "explicit"
)

type DefaultAccessPolicy string

const (
	DefaultAccessPolicyNobody  DefaultAccessPolicy = "nobody"
	DefaultAccessPolicyByTag   DefaultAccessPolicy = "tag"
	DefaultAccessPolicyOpen    DefaultAccessPolicy = "open"
)

type CommandType string

const (
	CommandApplyConfig       CommandType = "apply_config"
	CommandRestart           CommandType = "restart"
	CommandReload            CommandType = "reload"
	CommandDisable           CommandType = "disable"
	CommandRotateCredential  CommandType = "rotate_credentials"
	CommandPing              CommandType = "ping"
)

type CommandStatus string

const (
	CommandStatusPending CommandStatus = "pending"
	CommandStatusDone    CommandStatus = "done"
	CommandStatusFailed  CommandStatus = "failed"
)

type NodeEventLevel string

const (
	NodeEventLevelInfo  NodeEventLevel = "info"
	NodeEventLevelWarn  NodeEventLevel = "warn"
	NodeEventLevelError NodeEventLevel = "error"
)

type NodeEventSource string

const (
	NodeEventSourcePanel NodeEventSource = "panel"
	NodeEventSourceAgent NodeEventSource = "agent"
)

type NodeEventType string

const (
	NodeEventTypeConnected         NodeEventType = "node_connected"
	NodeEventTypeDisconnected     NodeEventType = "node_disconnected"
	NodeEventTypeHeartbeatRestored NodeEventType = "node_heartbeat_restored"
	NodeEventTypeSingboxStarted   NodeEventType = "singbox_started"
	NodeEventTypeSingboxRestarted NodeEventType = "singbox_restarted"
	NodeEventTypeSingboxReloaded  NodeEventType = "singbox_reloaded"
	NodeEventTypeConfigApplyFailed NodeEventType = "config_apply_failed"
	NodeEventTypeCommandFailed    NodeEventType = "command_failed"
)

type Admin struct {
	ID             string    `json:"id"`
	Email          string    `json:"email"`
	PasswordHash   string    `json:"-"`
	CreatedAt      time.Time `json:"created_at"`
}

type User struct {
	ID                 string         `json:"id"`
	ExternalID         *string        `json:"external_id,omitempty"`
	Name               string         `json:"name"`
	Status             UserStatus     `json:"status"`
	TrafficLimitBytes  int64          `json:"traffic_limit_bytes"`
	TrafficUsedBytes   int64          `json:"traffic_used_bytes"`
	SubscriptionToken  string         `json:"subscription_token"`
	NodeAccessMode     NodeAccessMode `json:"node_access_mode"`
	SSPasswordEncrypted string        `json:"-"`
	TrojanPasswordEncrypted string    `json:"-"`
	Tags               []Tag          `json:"tags,omitempty"`
	AllowedNodeIDs     []string       `json:"allowed_node_ids,omitempty"`
	CreatedAt          time.Time      `json:"created_at"`
	UpdatedAt          time.Time      `json:"updated_at"`
}

type Tag struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	CreatedAt time.Time `json:"created_at"`
}

type Node struct {
	ID                    string              `json:"id"`
	Name                  string              `json:"name"`
	Domain                string              `json:"domain"`
	Status                NodeStatus          `json:"status"`
	DefaultAccessPolicy   DefaultAccessPolicy `json:"default_access_policy"`
	DefaultAccessTag      *string             `json:"default_access_tag,omitempty"`
	EnrollToken           string              `json:"-"`
	APIKey                string              `json:"-"`
	AgentVersion          string              `json:"agent_version"`
	SingboxVersion        string              `json:"singbox_version"`
	LastSeenAt            *time.Time          `json:"last_seen_at,omitempty"`
	ConfigOverride        json.RawMessage     `json:"config_override,omitempty"`
	CreatedAt             time.Time           `json:"created_at"`
	UpdatedAt             time.Time           `json:"updated_at"`
}

type GlobalConfig struct {
	ID          string    `json:"id"`
	ConfigJSON  json.RawMessage `json:"config_json"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type NodeCommand struct {
	ID         string        `json:"id"`
	NodeID     string        `json:"node_id"`
	Type       CommandType   `json:"type"`
	Payload    json.RawMessage `json:"payload"`
	Status     CommandStatus `json:"status"`
	Result     *string       `json:"result,omitempty"`
	IssuedAt   time.Time     `json:"issued_at"`
	AppliedAt  *time.Time    `json:"applied_at,omitempty"`
}

type UsageRecord struct {
	ID            string    `json:"id"`
	NodeID        string    `json:"node_id"`
	UserID        string    `json:"user_id"`
	UplinkBytes   int64     `json:"uplink_bytes"`
	DownlinkBytes int64     `json:"downlink_bytes"`
	CollectedAt   time.Time `json:"collected_at"`
}

type SubscriptionEnvelope struct {
	Version string                 `json:"version"`
	Nodes   []SubscriptionNode     `json:"nodes"`
	Meta    map[string]interface{} `json:"meta"`
}

type SubscriptionNode struct {
	NodeID  string                 `json:"node_id"`
	Name    string                 `json:"name"`
	Domain  string                 `json:"domain"`
	Config  map[string]interface{} `json:"config"`
}

type ProfilePageResponse struct {
	UserName     string        `json:"user_name"`
	UserStatus   UserStatus    `json:"user_status"`
	Subscription string        `json:"subscription_token"`
	Profiles     []ProfileItem `json:"profiles"`
	Message      string        `json:"message,omitempty"`
}

type ProfileItem struct {
	NodeID           string  `json:"node_id"`
	Name             string  `json:"name"`
	Server           string  `json:"server"`
	Port             int     `json:"port"`
	Method           string  `json:"method"`
	ClientPassword   string  `json:"client_password"`
	PasswordMasked   string  `json:"password_masked"`
	SSURI            string  `json:"ss_uri"`
	LastSeenAt       *time.Time `json:"last_seen_at,omitempty"`
	Status           string  `json:"status"`
}

type EnrollResponse struct {
	NodeID         string          `json:"node_id"`
	NodeAPIKey     string          `json:"node_api_key"`
	DesiredConfig  map[string]any  `json:"desired_config"`
	Commands       []NodeCommand   `json:"commands"`
}

type NodeEvent struct {
	ID        string          `json:"id"`
	NodeID    string          `json:"node_id"`
	Level     NodeEventLevel  `json:"level"`
	Type      NodeEventType   `json:"type"`
	Message   string          `json:"message"`
	Source    NodeEventSource `json:"source"`
	CreatedAt time.Time       `json:"created_at"`
}
