package store

import (
	"testing"

	secretcrypto "github.com/fear/gulpo/apps/panel-api/internal/crypto"
	"github.com/fear/gulpo/apps/panel-api/internal/domain"
)

func TestMergeMapReplacesInboundArrays(t *testing.T) {
	base := map[string]any{
		"log": map[string]any{"level": "info"},
		"inbounds": []any{
			map[string]any{"type": "shadowsocks", "listen_port": 2080},
		},
	}
	override := map[string]any{
		"log": map[string]any{"level": "debug"},
		"inbounds": []any{
			map[string]any{"type": "trojan", "listen_port": 8443},
		},
	}

	got := mergeMap(base, override)
	inbounds, ok := got["inbounds"].([]any)
	if !ok || len(inbounds) != 1 {
		t.Fatalf("expected single overridden inbound, got %#v", got["inbounds"])
	}
	if inbounds[0].(map[string]any)["type"] != "trojan" {
		t.Fatalf("expected trojan inbound replacement")
	}
	if got["log"].(map[string]any)["level"] != "debug" {
		t.Fatalf("expected nested map override")
	}
}

func TestResolveNodeRuntimeConfigPatchesSupportedProtocols(t *testing.T) {
	box := secretcrypto.NewSecretBox("test-secret")
	ssPassword, err := box.Encrypt("ss-user-secret")
	if err != nil {
		t.Fatalf("encrypt ss: %v", err)
	}
	trojanPassword, err := box.Encrypt("trojan-user-secret")
	if err != nil {
		t.Fatalf("encrypt trojan: %v", err)
	}

	store := &PostgresStore{secrets: box}
	node := domain.Node{Domain: "edge.example.com"}
	cfg := map[string]any{
		"inbounds": []any{
			map[string]any{
				"type":        "shadowsocks",
				"listen_port": 2080,
				"method":      "aes-128-gcm",
			},
			map[string]any{
				"type":        "trojan",
				"listen_port": 8443,
				"tls": map[string]any{
					"enabled": true,
					"acme": map[string]any{
						"enabled": true,
					},
				},
			},
		},
	}
	users := []domain.User{{
		ID:                      "user-1",
		SSPasswordEncrypted:     ssPassword,
		TrojanPasswordEncrypted: trojanPassword,
	}}

	got, err := store.resolveNodeRuntimeConfig(node, cfg, users)
	if err != nil {
		t.Fatalf("resolve runtime config: %v", err)
	}
	inbounds := got["inbounds"].([]any)

	ssUsers := inbounds[0].(map[string]any)["users"].([]map[string]any)
	if len(ssUsers) != 1 || ssUsers[0]["password"] != "ss-user-secret" {
		t.Fatalf("expected generated shadowsocks user, got %#v", ssUsers)
	}

	trojanInbound := inbounds[1].(map[string]any)
	trojanUsers := trojanInbound["users"].([]map[string]any)
	if len(trojanUsers) != 1 || trojanUsers[0]["password"] != "trojan-user-secret" {
		t.Fatalf("expected generated trojan user, got %#v", trojanUsers)
	}
	tlsConfig := trojanInbound["tls"].(map[string]any)
	if tlsConfig["server_name"] != "edge.example.com" {
		t.Fatalf("expected default tls server_name, got %#v", tlsConfig["server_name"])
	}
	acmeConfig := tlsConfig["acme"].(map[string]any)
	domains := acmeConfig["domain"].([]string)
	if len(domains) != 1 || domains[0] != "edge.example.com" {
		t.Fatalf("expected default acme domain, got %#v", acmeConfig["domain"])
	}
	if acmeConfig["data_directory"] != "__GULPO_ACME_DATA_DIR__" {
		t.Fatalf("expected acme data dir placeholder, got %#v", acmeConfig["data_directory"])
	}
}
