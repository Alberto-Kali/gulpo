package store

import (
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"github.com/fear/gulpo/apps/panel-api/internal/auth"
	secretcrypto "github.com/fear/gulpo/apps/panel-api/internal/crypto"
	"github.com/fear/gulpo/apps/panel-api/internal/domain"
	"github.com/google/uuid"
	_ "github.com/jackc/pgx/v5/stdlib"
)

type PostgresStore struct {
	db      *sql.DB
	secrets *secretcrypto.SecretBox
}

func Open(ctx context.Context, databaseURL, ssSecretKey string) (*PostgresStore, error) {
	db, err := sql.Open("pgx", databaseURL)
	if err != nil {
		return nil, err
	}
	if err := db.PingContext(ctx); err != nil {
		return nil, err
	}
	return &PostgresStore{
		db: db,
		secrets: secretcrypto.NewSecretBox(ssSecretKey),
	}, nil
}

func (s *PostgresStore) Close() error {
	return s.db.Close()
}

func (s *PostgresStore) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schemaSQL)
	return err
}

func (s *PostgresStore) SeedAdmin(ctx context.Context, email, password string) error {
	var exists bool
	if err := s.db.QueryRowContext(ctx, `select exists(select 1 from admins where email = $1)`, email).Scan(&exists); err != nil {
		return err
	}
	if exists {
		return nil
	}
	_, err := s.db.ExecContext(ctx, `
		insert into admins (id, email, password_hash, created_at)
		values ($1, $2, $3, now())`,
		uuid.NewString(), email, auth.HashPassword(password),
	)
	return err
}

func (s *PostgresStore) GetAdminByEmail(ctx context.Context, email string) (domain.Admin, error) {
	row := s.db.QueryRowContext(ctx, `select id, email, password_hash, created_at from admins where email = $1`, email)
	var admin domain.Admin
	err := row.Scan(&admin.ID, &admin.Email, &admin.PasswordHash, &admin.CreatedAt)
	return admin, err
}

func (s *PostgresStore) ListUsers(ctx context.Context) ([]domain.User, error) {
	rows, err := s.db.QueryContext(ctx, `
		select id, external_id, name, status, traffic_limit_bytes, traffic_used_bytes, subscription_token, node_access_mode, ss_password_encrypted, trojan_password_encrypted, created_at, updated_at
		from users
		order by created_at desc`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []domain.User
	for rows.Next() {
		var user domain.User
		if err := rows.Scan(
			&user.ID,
			&user.ExternalID,
			&user.Name,
			&user.Status,
			&user.TrafficLimitBytes,
			&user.TrafficUsedBytes,
			&user.SubscriptionToken,
			&user.NodeAccessMode,
			&user.SSPasswordEncrypted,
			&user.TrojanPasswordEncrypted,
			&user.CreatedAt,
			&user.UpdatedAt,
		); err != nil {
			return nil, err
		}
		if err := s.ensureUserSecrets(ctx, &user); err != nil {
			return nil, err
		}
		user.Tags, _ = s.ListUserTags(ctx, user.ID)
		user.AllowedNodeIDs, _ = s.ListUserAllowedNodes(ctx, user.ID)
		users = append(users, user)
	}
	return users, rows.Err()
}

func (s *PostgresStore) CreateUser(ctx context.Context, user domain.User) (domain.User, error) {
	if user.ID == "" {
		user.ID = uuid.NewString()
	}
	if user.SubscriptionToken == "" {
		token, err := auth.RandomToken(24)
		if err != nil {
			return domain.User{}, err
		}
		user.SubscriptionToken = token
	}
	if err := s.ensureSecretFields(&user); err != nil {
		return domain.User{}, err
	}
	err := s.db.QueryRowContext(ctx, `
		insert into users (id, external_id, name, status, traffic_limit_bytes, traffic_used_bytes, subscription_token, node_access_mode, ss_password_encrypted, trojan_password_encrypted, created_at, updated_at)
		values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),now())
		returning created_at, updated_at`,
		user.ID,
		user.ExternalID,
		user.Name,
		user.Status,
		user.TrafficLimitBytes,
		user.TrafficUsedBytes,
		user.SubscriptionToken,
		user.NodeAccessMode,
		user.SSPasswordEncrypted,
		user.TrojanPasswordEncrypted,
	).Scan(&user.CreatedAt, &user.UpdatedAt)
	return user, err
}

func (s *PostgresStore) UpdateUser(ctx context.Context, id string, user domain.User) (domain.User, error) {
	row := s.db.QueryRowContext(ctx, `
		update users
		set external_id = $2, name = $3, status = $4, traffic_limit_bytes = $5, node_access_mode = $6, updated_at = now()
		where id = $1
		returning id, external_id, name, status, traffic_limit_bytes, traffic_used_bytes, subscription_token, node_access_mode, ss_password_encrypted, trojan_password_encrypted, created_at, updated_at`,
		id, user.ExternalID, user.Name, user.Status, user.TrafficLimitBytes, user.NodeAccessMode,
	)
	var out domain.User
	err := row.Scan(
		&out.ID,
		&out.ExternalID,
		&out.Name,
		&out.Status,
		&out.TrafficLimitBytes,
		&out.TrafficUsedBytes,
		&out.SubscriptionToken,
		&out.NodeAccessMode,
		&out.SSPasswordEncrypted,
		&out.TrojanPasswordEncrypted,
		&out.CreatedAt,
		&out.UpdatedAt,
	)
	if err != nil {
		return domain.User{}, err
	}
	out.Tags, _ = s.ListUserTags(ctx, out.ID)
	out.AllowedNodeIDs, _ = s.ListUserAllowedNodes(ctx, out.ID)
	return out, nil
}

func (s *PostgresStore) DeleteUser(ctx context.Context, id string) error {
	_, err := s.db.ExecContext(ctx, `delete from users where id = $1`, id)
	return err
}

func (s *PostgresStore) GetUserBySubscriptionToken(ctx context.Context, token string) (domain.User, error) {
	row := s.db.QueryRowContext(ctx, `
		select id, external_id, name, status, traffic_limit_bytes, traffic_used_bytes, subscription_token, node_access_mode, ss_password_encrypted, trojan_password_encrypted, created_at, updated_at
		from users where subscription_token = $1`, token)
	var user domain.User
	err := row.Scan(
		&user.ID,
		&user.ExternalID,
		&user.Name,
		&user.Status,
		&user.TrafficLimitBytes,
		&user.TrafficUsedBytes,
		&user.SubscriptionToken,
		&user.NodeAccessMode,
		&user.SSPasswordEncrypted,
		&user.TrojanPasswordEncrypted,
		&user.CreatedAt,
		&user.UpdatedAt,
	)
	if err != nil {
		return domain.User{}, err
	}
	if err := s.ensureUserSecrets(ctx, &user); err != nil {
		return domain.User{}, err
	}
	user.Tags, _ = s.ListUserTags(ctx, user.ID)
	user.AllowedNodeIDs, _ = s.ListUserAllowedNodes(ctx, user.ID)
	return user, nil
}

func (s *PostgresStore) RotateSubscriptionToken(ctx context.Context, userID string) (string, error) {
	token, err := auth.RandomToken(24)
	if err != nil {
		return "", err
	}
	_, err = s.db.ExecContext(ctx, `update users set subscription_token = $2, updated_at = now() where id = $1`, userID, token)
	return token, err
}

func (s *PostgresStore) ListUserTags(ctx context.Context, userID string) ([]domain.Tag, error) {
	rows, err := s.db.QueryContext(ctx, `
		select t.id, t.name, t.created_at
		from tags t
		join user_tags ut on ut.tag_id = t.id
		where ut.user_id = $1
		order by t.name`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tags []domain.Tag
	for rows.Next() {
		var tag domain.Tag
		if err := rows.Scan(&tag.ID, &tag.Name, &tag.CreatedAt); err != nil {
			return nil, err
		}
		tags = append(tags, tag)
	}
	return tags, rows.Err()
}

func (s *PostgresStore) AttachTagsToUser(ctx context.Context, userID string, tagNames []string) ([]domain.Tag, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `delete from user_tags where user_id = $1`, userID); err != nil {
		return nil, err
	}
	var tags []domain.Tag
	for _, name := range tagNames {
		var tag domain.Tag
		err := tx.QueryRowContext(ctx, `
			insert into tags (id, name, created_at)
			values ($1, $2, now())
			on conflict (name) do update set name = excluded.name
			returning id, name, created_at`,
			uuid.NewString(), name,
		).Scan(&tag.ID, &tag.Name, &tag.CreatedAt)
		if err != nil {
			return nil, err
		}
		if _, err := tx.ExecContext(ctx, `insert into user_tags (user_id, tag_id) values ($1, $2) on conflict do nothing`, userID, tag.ID); err != nil {
			return nil, err
		}
		tags = append(tags, tag)
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return tags, nil
}

func (s *PostgresStore) ReplaceAllowedNodes(ctx context.Context, userID string, nodeIDs []string) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `delete from user_node_access where user_id = $1`, userID); err != nil {
		return err
	}
	for _, nodeID := range nodeIDs {
		if _, err := tx.ExecContext(ctx, `insert into user_node_access (user_id, node_id) values ($1, $2)`, userID, nodeID); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s *PostgresStore) ListUserAllowedNodes(ctx context.Context, userID string) ([]string, error) {
	rows, err := s.db.QueryContext(ctx, `select node_id from user_node_access where user_id = $1 order by node_id`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var nodeIDs []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		nodeIDs = append(nodeIDs, id)
	}
	return nodeIDs, rows.Err()
}

func (s *PostgresStore) ListNodes(ctx context.Context) ([]domain.Node, error) {
	rows, err := s.db.QueryContext(ctx, `
		select id, name, domain, status, default_access_policy, default_access_tag, enroll_token, api_key, agent_version, singbox_version, last_seen_at, config_override, created_at, updated_at
		from nodes order by created_at desc`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var nodes []domain.Node
	for rows.Next() {
		var node domain.Node
		if err := rows.Scan(&node.ID, &node.Name, &node.Domain, &node.Status, &node.DefaultAccessPolicy, &node.DefaultAccessTag, &node.EnrollToken, &node.APIKey, &node.AgentVersion, &node.SingboxVersion, &node.LastSeenAt, &node.ConfigOverride, &node.CreatedAt, &node.UpdatedAt); err != nil {
			return nil, err
		}
		nodes = append(nodes, node)
	}
	return nodes, rows.Err()
}

func (s *PostgresStore) ListNodeEvents(ctx context.Context, nodeID string, limit int) ([]domain.NodeEvent, error) {
	if limit <= 0 || limit > 1000 {
		limit = 100
	}
	rows, err := s.db.QueryContext(ctx, `
		select id, node_id, level, type, message, source, created_at
		from node_events
		where node_id = $1
		order by created_at desc
		limit $2`, nodeID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var events []domain.NodeEvent
	for rows.Next() {
		var event domain.NodeEvent
		if err := rows.Scan(&event.ID, &event.NodeID, &event.Level, &event.Type, &event.Message, &event.Source, &event.CreatedAt); err != nil {
			return nil, err
		}
		events = append(events, event)
	}
	return events, rows.Err()
}

func (s *PostgresStore) CreateNodeEvent(ctx context.Context, event domain.NodeEvent) (domain.NodeEvent, error) {
	if event.ID == "" {
		event.ID = uuid.NewString()
	}
	if event.Level == "" {
		event.Level = domain.NodeEventLevelInfo
	}
	if event.Source == "" {
		event.Source = domain.NodeEventSourceAgent
	}
	err := s.db.QueryRowContext(ctx, `
		insert into node_events (id, node_id, level, type, message, source, created_at)
		values ($1, $2, $3, $4, $5, $6, now())
		returning created_at`,
		event.ID, event.NodeID, event.Level, event.Type, event.Message, event.Source,
	).Scan(&event.CreatedAt)
	return event, err
}

func (s *PostgresStore) CreateNodeEvents(ctx context.Context, nodeID string, events []domain.NodeEvent) error {
	if len(events) == 0 {
		return nil
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for _, event := range events {
		if event.ID == "" {
			event.ID = uuid.NewString()
		}
		if event.Level == "" {
			event.Level = domain.NodeEventLevelInfo
		}
		if event.Source == "" {
			event.Source = domain.NodeEventSourceAgent
		}
		if _, err := tx.ExecContext(ctx, `
			insert into node_events (id, node_id, level, type, message, source, created_at)
			values ($1, $2, $3, $4, $5, $6, now())`,
			event.ID, nodeID, event.Level, event.Type, event.Message, event.Source,
		); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s *PostgresStore) CreateNode(ctx context.Context, node domain.Node) (domain.Node, error) {
	if node.ID == "" {
		node.ID = uuid.NewString()
	}
	if node.EnrollToken == "" {
		token, err := auth.RandomToken(24)
		if err != nil {
			return domain.Node{}, err
		}
		node.EnrollToken = token
	}
	if node.APIKey == "" {
		key, err := auth.RandomToken(24)
		if err != nil {
			return domain.Node{}, err
		}
		node.APIKey = key
	}
	err := s.db.QueryRowContext(ctx, `
		insert into nodes (id, name, domain, status, default_access_policy, default_access_tag, enroll_token, api_key, agent_version, singbox_version, config_override, created_at, updated_at)
		values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,now(),now())
		returning created_at, updated_at`,
		node.ID, node.Name, node.Domain, node.Status, node.DefaultAccessPolicy, node.DefaultAccessTag, node.EnrollToken, node.APIKey, node.AgentVersion, node.SingboxVersion, node.ConfigOverride,
	).Scan(&node.CreatedAt, &node.UpdatedAt)
	return node, err
}

func (s *PostgresStore) UpdateNode(ctx context.Context, id string, node domain.Node) (domain.Node, error) {
	row := s.db.QueryRowContext(ctx, `
		update nodes set name = $2, domain = $3, status = $4, default_access_policy = $5, default_access_tag = $6, agent_version = $7, singbox_version = $8, updated_at = now()
		where id = $1
		returning id, name, domain, status, default_access_policy, default_access_tag, enroll_token, api_key, agent_version, singbox_version, last_seen_at, config_override, created_at, updated_at`,
		id, node.Name, node.Domain, node.Status, node.DefaultAccessPolicy, node.DefaultAccessTag, node.AgentVersion, node.SingboxVersion,
	)
	var out domain.Node
	err := row.Scan(&out.ID, &out.Name, &out.Domain, &out.Status, &out.DefaultAccessPolicy, &out.DefaultAccessTag, &out.EnrollToken, &out.APIKey, &out.AgentVersion, &out.SingboxVersion, &out.LastSeenAt, &out.ConfigOverride, &out.CreatedAt, &out.UpdatedAt)
	return out, err
}

func (s *PostgresStore) DeleteNode(ctx context.Context, id string) error {
	_, err := s.db.ExecContext(ctx, `delete from nodes where id = $1`, id)
	return err
}

func (s *PostgresStore) RotateEnrollToken(ctx context.Context, nodeID string) (string, error) {
	token, err := auth.RandomToken(24)
	if err != nil {
		return "", err
	}
	_, err = s.db.ExecContext(ctx, `update nodes set enroll_token = $2, updated_at = now() where id = $1`, nodeID, token)
	return token, err
}

func (s *PostgresStore) GetGlobalConfig(ctx context.Context) (domain.GlobalConfig, error) {
	row := s.db.QueryRowContext(ctx, `select id, config_json, updated_at from global_config limit 1`)
	var cfg domain.GlobalConfig
	err := row.Scan(&cfg.ID, &cfg.ConfigJSON, &cfg.UpdatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		cfg = domain.GlobalConfig{ID: uuid.NewString(), ConfigJSON: []byte(`{"inbounds":[],"outbounds":[]}`)}
		_, insertErr := s.db.ExecContext(ctx, `insert into global_config (id, config_json, updated_at) values ($1, $2, now())`, cfg.ID, cfg.ConfigJSON)
		return cfg, insertErr
	}
	return cfg, err
}

func (s *PostgresStore) UpdateGlobalConfig(ctx context.Context, data []byte) (domain.GlobalConfig, error) {
	cfg, err := s.GetGlobalConfig(ctx)
	if err != nil {
		return domain.GlobalConfig{}, err
	}
	_, err = s.db.ExecContext(ctx, `update global_config set config_json = $2, updated_at = now() where id = $1`, cfg.ID, data)
	if err != nil {
		return domain.GlobalConfig{}, err
	}
	cfg.ConfigJSON = data
	cfg.UpdatedAt = time.Now()
	return cfg, nil
}

func (s *PostgresStore) GetNodeConfig(ctx context.Context, nodeID string) ([]byte, error) {
	var cfg []byte
	err := s.db.QueryRowContext(ctx, `select config_override from nodes where id = $1`, nodeID).Scan(&cfg)
	return cfg, err
}

func (s *PostgresStore) UpdateNodeConfig(ctx context.Context, nodeID string, data []byte) error {
	_, err := s.db.ExecContext(ctx, `update nodes set config_override = $2, updated_at = now() where id = $1`, nodeID, data)
	return err
}

func (s *PostgresStore) CreateNodeCommand(ctx context.Context, cmd domain.NodeCommand) (domain.NodeCommand, error) {
	if cmd.ID == "" {
		cmd.ID = uuid.NewString()
	}
	err := s.db.QueryRowContext(ctx, `
		insert into node_commands (id, node_id, type, payload, status, result, issued_at)
		values ($1,$2,$3,$4,$5,$6,now())
		returning issued_at`,
		cmd.ID, cmd.NodeID, cmd.Type, cmd.Payload, domain.CommandStatusPending, cmd.Result,
	).Scan(&cmd.IssuedAt)
	cmd.Status = domain.CommandStatusPending
	return cmd, err
}

func (s *PostgresStore) ListPendingNodeCommands(ctx context.Context, nodeID string) ([]domain.NodeCommand, error) {
	rows, err := s.db.QueryContext(ctx, `
		select id, node_id, type, payload, status, result, issued_at, applied_at
		from node_commands
		where node_id = $1 and status = 'pending'
		order by issued_at`, nodeID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var commands []domain.NodeCommand
	for rows.Next() {
		var cmd domain.NodeCommand
		if err := rows.Scan(&cmd.ID, &cmd.NodeID, &cmd.Type, &cmd.Payload, &cmd.Status, &cmd.Result, &cmd.IssuedAt, &cmd.AppliedAt); err != nil {
			return nil, err
		}
		commands = append(commands, cmd)
	}
	return commands, rows.Err()
}

func (s *PostgresStore) CompleteNodeCommand(ctx context.Context, id string, status domain.CommandStatus, result string) error {
	_, err := s.db.ExecContext(ctx, `update node_commands set status = $2, result = $3, applied_at = now() where id = $1`, id, status, result)
	return err
}

func (s *PostgresStore) EnrollNode(ctx context.Context, enrollToken, agentVersion, singboxVersion string) (domain.Node, error) {
	var previousStatus domain.NodeStatus
	_ = s.db.QueryRowContext(ctx, `select status from nodes where enroll_token = $1`, enrollToken).Scan(&previousStatus)
	var node domain.Node
	row := s.db.QueryRowContext(ctx, `
		update nodes
		set agent_version = $2, singbox_version = $3, status = 'online', last_seen_at = now(), updated_at = now()
		where enroll_token = $1
		returning id, name, domain, status, default_access_policy, default_access_tag, enroll_token, api_key, agent_version, singbox_version, last_seen_at, config_override, created_at, updated_at`,
		enrollToken, agentVersion, singboxVersion,
	)
	err := row.Scan(&node.ID, &node.Name, &node.Domain, &node.Status, &node.DefaultAccessPolicy, &node.DefaultAccessTag, &node.EnrollToken, &node.APIKey, &node.AgentVersion, &node.SingboxVersion, &node.LastSeenAt, &node.ConfigOverride, &node.CreatedAt, &node.UpdatedAt)
	if err == nil && previousStatus != domain.NodeStatusOnline {
		message := "Node connected to panel."
		eventType := domain.NodeEventTypeConnected
		if previousStatus == domain.NodeStatusOffline {
			message = "Node reconnected after offline state."
			eventType = domain.NodeEventTypeHeartbeatRestored
		}
		_, _ = s.CreateNodeEvent(ctx, domain.NodeEvent{
			NodeID:  node.ID,
			Level:   domain.NodeEventLevelInfo,
			Type:    eventType,
			Message: message,
			Source:  domain.NodeEventSourcePanel,
		})
	}
	return node, err
}

func (s *PostgresStore) GetNodeByAPIKey(ctx context.Context, apiKey string) (domain.Node, error) {
	row := s.db.QueryRowContext(ctx, `
		select id, name, domain, status, default_access_policy, default_access_tag, enroll_token, api_key, agent_version, singbox_version, last_seen_at, config_override, created_at, updated_at
		from nodes where api_key = $1`, apiKey)
	var node domain.Node
	err := row.Scan(&node.ID, &node.Name, &node.Domain, &node.Status, &node.DefaultAccessPolicy, &node.DefaultAccessTag, &node.EnrollToken, &node.APIKey, &node.AgentVersion, &node.SingboxVersion, &node.LastSeenAt, &node.ConfigOverride, &node.CreatedAt, &node.UpdatedAt)
	return node, err
}

func (s *PostgresStore) TouchNodeHeartbeat(ctx context.Context, nodeID, agentVersion, singboxVersion string) error {
	var previousStatus domain.NodeStatus
	_ = s.db.QueryRowContext(ctx, `select status from nodes where id = $1`, nodeID).Scan(&previousStatus)
	_, err := s.db.ExecContext(ctx, `
		update nodes
		set last_seen_at = now(), status = 'online', agent_version = $2, singbox_version = $3, updated_at = now()
		where id = $1`, nodeID, agentVersion, singboxVersion)
	if err == nil && previousStatus != domain.NodeStatusOnline {
		_, _ = s.CreateNodeEvent(ctx, domain.NodeEvent{
			NodeID:  nodeID,
			Level:   domain.NodeEventLevelInfo,
			Type:    domain.NodeEventTypeHeartbeatRestored,
			Message: "Heartbeat restored and node is online again.",
			Source:  domain.NodeEventSourcePanel,
		})
	}
	return err
}

func (s *PostgresStore) ReconcileStaleNodes(ctx context.Context, timeout time.Duration) error {
	if timeout <= 0 {
		timeout = 60 * time.Second
	}
	rows, err := s.db.QueryContext(ctx, `
		update nodes
		set status = 'offline', updated_at = now()
		where status = 'online' and last_seen_at is not null and last_seen_at < now() - $1::interval
		returning id`, durationInterval(timeout))
	if err != nil {
		return err
	}
	defer rows.Close()
	var nodeIDs []string
	for rows.Next() {
		var nodeID string
		if err := rows.Scan(&nodeID); err != nil {
			return err
		}
		nodeIDs = append(nodeIDs, nodeID)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	for _, nodeID := range nodeIDs {
		_, _ = s.CreateNodeEvent(ctx, domain.NodeEvent{
			NodeID:  nodeID,
			Level:   domain.NodeEventLevelWarn,
			Type:    domain.NodeEventTypeDisconnected,
			Message: "Node heartbeat timed out and node was marked offline.",
			Source:  domain.NodeEventSourcePanel,
		})
	}
	return nil
}

func (s *PostgresStore) SaveUsageBatch(ctx context.Context, nodeID string, records []domain.UsageRecord) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for _, record := range records {
		if record.ID == "" {
			record.ID = uuid.NewString()
		}
		if _, err := tx.ExecContext(ctx, `
			insert into usage_records (id, node_id, user_id, uplink_bytes, downlink_bytes, collected_at)
			values ($1,$2,$3,$4,$5,$6)`,
			record.ID, nodeID, record.UserID, record.UplinkBytes, record.DownlinkBytes, record.CollectedAt,
		); err != nil {
			return err
		}
		if _, err := tx.ExecContext(ctx, `
			update users
			set traffic_used_bytes = traffic_used_bytes + $2 + $3, updated_at = now()
			where id = $1`,
			record.UserID, record.UplinkBytes, record.DownlinkBytes,
		); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s *PostgresStore) BuildSubscription(ctx context.Context, user domain.User) (domain.SubscriptionEnvelope, error) {
	nodes, err := s.AccessibleNodesForUser(ctx, user)
	if err != nil {
		return domain.SubscriptionEnvelope{}, err
	}
	envelope := domain.SubscriptionEnvelope{
		Version: "1",
		Meta: map[string]interface{}{
			"user_id":       user.ID,
			"generated_at":  time.Now().UTC().Format(time.RFC3339),
			"transport":     "shadowsocks",
			"subscription":  user.SubscriptionToken,
		},
	}
	if !isUserEligible(user) {
		return envelope, nil
	}
	for _, node := range nodes {
		nodeConfig, err := s.BuildMergedNodeConfig(ctx, node)
		if err != nil {
			return domain.SubscriptionEnvelope{}, err
		}
		nodeConfig["domain"] = node.Domain
		nodeConfig["user"] = map[string]any{
			"id":                 user.ID,
			"name":               user.Name,
			"subscription_token": user.SubscriptionToken,
		}
		envelope.Nodes = append(envelope.Nodes, domain.SubscriptionNode{
			NodeID: node.ID,
			Name:   node.Name,
			Domain: node.Domain,
			Config: nodeConfig,
		})
	}
	return envelope, nil
}

func (s *PostgresStore) BuildProfilePage(ctx context.Context, user domain.User) (domain.ProfilePageResponse, error) {
	response := domain.ProfilePageResponse{
		UserName:     user.Name,
		UserStatus:   user.Status,
		Subscription: user.SubscriptionToken,
	}
	if !isUserEligible(user) {
		response.Message = "This subscription is inactive or traffic limit is exhausted."
		return response, nil
	}
	nodes, err := s.AccessibleNodesForUser(ctx, user)
	if err != nil {
		return response, err
	}
	userPassword, err := s.secrets.Decrypt(user.SSPasswordEncrypted)
	if err != nil {
		return response, err
	}
	for _, node := range nodes {
		mergedConfig, err := s.BuildMergedNodeConfig(ctx, node)
		if err != nil {
			return response, err
		}
		inbound, ssConfig, ok := firstShadowsocksInbound(mergedConfig)
		if !ok {
			continue
		}
		serverPassword, _ := inbound["password"].(string)
		clientPassword := composeClientPassword(ssConfig.Method, serverPassword, userPassword)
		server := normalizeServer(node.Domain)
		response.Profiles = append(response.Profiles, domain.ProfileItem{
			NodeID:         node.ID,
			Name:           node.Name,
			Server:         server,
			Port:           ssConfig.Port,
			Method:         ssConfig.Method,
			ClientPassword: clientPassword,
			PasswordMasked: maskSecret(clientPassword),
			SSURI:          buildSSURI(ssConfig.Method, clientPassword, server, ssConfig.Port, fmt.Sprintf("%s %s", user.Name, node.Name)),
			LastSeenAt:     node.LastSeenAt,
			Status:         string(node.Status),
		})
	}
	if len(response.Profiles) == 0 {
		response.Message = "No eligible Shadowsocks profiles are available for this subscription."
	}
	return response, nil
}

func (s *PostgresStore) BuildNodeDesiredConfig(ctx context.Context, node domain.Node) (map[string]any, error) {
	merged, err := s.BuildMergedNodeConfig(ctx, node)
	if err != nil {
		return nil, err
	}
	users, err := s.ListEligibleUsersForNode(ctx, node)
	if err != nil {
		return nil, err
	}
	return s.resolveNodeRuntimeConfig(node, merged, users)
}

func (s *PostgresStore) BuildMergedNodeConfig(ctx context.Context, node domain.Node) (map[string]any, error) {
	globalCfg, err := s.GetGlobalConfig(ctx)
	if err != nil {
		return nil, err
	}
	var merged map[string]any
	if err := json.Unmarshal(globalCfg.ConfigJSON, &merged); err != nil {
		return nil, err
	}
	if merged == nil {
		merged = map[string]any{}
	}
	if len(node.ConfigOverride) > 0 {
		var override map[string]any
		if err := json.Unmarshal(node.ConfigOverride, &override); err == nil && override != nil {
			merged = mergeMap(merged, override)
		}
	}
	return cloneMap(merged), nil
}

func (s *PostgresStore) AccessibleNodesForUser(ctx context.Context, user domain.User) ([]domain.Node, error) {
	nodes, err := s.ListNodes(ctx)
	if err != nil {
		return nil, err
	}
	var allowed []domain.Node
	for _, node := range nodes {
		if userCanAccessNode(user, node) {
			allowed = append(allowed, node)
		}
	}
	return allowed, nil
}

func (s *PostgresStore) ListEligibleUsersForNode(ctx context.Context, node domain.Node) ([]domain.User, error) {
	users, err := s.ListUsers(ctx)
	if err != nil {
		return nil, err
	}
	var eligible []domain.User
	for _, user := range users {
		if isUserEligible(user) && userCanAccessNode(user, node) {
			eligible = append(eligible, user)
		}
	}
	return eligible, nil
}

func (s *PostgresStore) resolveNodeRuntimeConfig(node domain.Node, cfg map[string]any, users []domain.User) (map[string]any, error) {
	rawInbounds, ok := cfg["inbounds"].([]any)
	if !ok {
		return cfg, nil
	}
	for _, raw := range rawInbounds {
		inbound, ok := raw.(map[string]any)
		if !ok {
			continue
		}
		applyNodeTLSDefaults(inbound, node)
		switch asString(inbound["type"]) {
		case "shadowsocks":
			method := asString(inbound["method"])
			if method == "" {
				continue
			}
			runtimeUsers := make([]map[string]any, 0, len(users))
			for _, user := range users {
				password, err := s.secrets.Decrypt(user.SSPasswordEncrypted)
				if err != nil {
					return nil, err
				}
				runtimeUsers = append(runtimeUsers, map[string]any{
					"name":     user.ID,
					"password": password,
				})
			}
			inbound["users"] = runtimeUsers
			inbound["tag"] = coalesceString(asString(inbound["tag"]), "ss-in")
		case "trojan":
			runtimeUsers := make([]map[string]any, 0, len(users))
			for _, user := range users {
				password, err := s.secrets.Decrypt(user.TrojanPasswordEncrypted)
				if err != nil {
					return nil, err
				}
				runtimeUsers = append(runtimeUsers, map[string]any{
					"name":     user.ID,
					"password": password,
				})
			}
			inbound["users"] = runtimeUsers
			inbound["tag"] = coalesceString(asString(inbound["tag"]), "trojan-in")
		}
	}
	return cfg, nil
}

func (s *PostgresStore) ensureSecretFields(user *domain.User) error {
	if user.SSPasswordEncrypted == "" {
		plainPassword, err := auth.RandomToken(18)
		if err != nil {
			return err
		}
		encrypted, err := s.secrets.Encrypt(plainPassword)
		if err != nil {
			return err
		}
		user.SSPasswordEncrypted = encrypted
	}
	if user.TrojanPasswordEncrypted == "" {
		plainPassword, err := auth.RandomToken(24)
		if err != nil {
			return err
		}
		encrypted, err := s.secrets.Encrypt(plainPassword)
		if err != nil {
			return err
		}
		user.TrojanPasswordEncrypted = encrypted
	}
	return nil
}

func (s *PostgresStore) ensureUserSecrets(ctx context.Context, user *domain.User) error {
	if user.SSPasswordEncrypted != "" && user.TrojanPasswordEncrypted != "" {
		return nil
	}
	if err := s.ensureSecretFields(user); err != nil {
		return err
	}
	if _, err := s.db.ExecContext(ctx, `
		update users
		set ss_password_encrypted = $2, trojan_password_encrypted = $3, updated_at = now()
		where id = $1`,
		user.ID, user.SSPasswordEncrypted, user.TrojanPasswordEncrypted,
	); err != nil {
		return err
	}
	return nil
}

func isUserEligible(user domain.User) bool {
	if user.Status != domain.UserStatusActive {
		return false
	}
	return user.TrafficLimitBytes <= 0 || user.TrafficUsedBytes < user.TrafficLimitBytes
}

func userCanAccessNode(user domain.User, node domain.Node) bool {
	if node.Status == domain.NodeStatusDisabled {
		return false
	}
	switch user.NodeAccessMode {
	case domain.NodeAccessModeExplicit:
		for _, id := range user.AllowedNodeIDs {
			if id == node.ID {
				return true
			}
		}
		return false
	default:
		tagSet := map[string]bool{}
		for _, tag := range user.Tags {
			tagSet[tag.Name] = true
		}
		switch node.DefaultAccessPolicy {
		case domain.DefaultAccessPolicyOpen:
			return true
		case domain.DefaultAccessPolicyByTag:
			return node.DefaultAccessTag != nil && tagSet[*node.DefaultAccessTag]
		default:
			return false
		}
	}
}

type shadowsocksInbound struct {
	Port   int
	Method string
}

func firstShadowsocksInbound(config map[string]any) (map[string]any, shadowsocksInbound, bool) {
	rawInbounds, ok := config["inbounds"].([]any)
	if !ok {
		return nil, shadowsocksInbound{}, false
	}
	for _, raw := range rawInbounds {
		inbound, ok := raw.(map[string]any)
		if !ok {
			continue
		}
		if asString(inbound["type"]) != "shadowsocks" {
			continue
		}
		port, ok := asInt(inbound["listen_port"])
		if !ok {
			continue
		}
		method := asString(inbound["method"])
		if method == "" {
			continue
		}
		return inbound, shadowsocksInbound{
			Port:   port,
			Method: method,
		}, true
	}
	return nil, shadowsocksInbound{}, false
}

func asInt(value any) (int, bool) {
	switch typed := value.(type) {
	case int:
		return typed, true
	case int64:
		return int(typed), true
	case float64:
		return int(typed), true
	case json.Number:
		i, err := typed.Int64()
		return int(i), err == nil
	default:
		return 0, false
	}
}

func asString(value any) string {
	typed, _ := value.(string)
	return typed
}

func coalesceString(value, fallback string) string {
	if value != "" {
		return value
	}
	return fallback
}

func applyNodeTLSDefaults(inbound map[string]any, node domain.Node) {
	tlsConfig, ok := inbound["tls"].(map[string]any)
	if !ok {
		return
	}
	serverName := normalizeServer(node.Domain)
	if serverName == "" {
		return
	}
	if asString(tlsConfig["server_name"]) == "" {
		tlsConfig["server_name"] = serverName
	}
	acmeConfig, ok := tlsConfig["acme"].(map[string]any)
	if !ok {
		return
	}
	if enabled, ok := acmeConfig["enabled"].(bool); ok && !enabled {
		delete(acmeConfig, "enabled")
		return
	}
	delete(acmeConfig, "enabled")
	if _, ok := acmeConfig["domain"]; !ok {
		acmeConfig["domain"] = []string{serverName}
	} else if domainName := asString(acmeConfig["domain"]); domainName != "" {
		acmeConfig["domain"] = []string{domainName}
	}
	if asString(acmeConfig["data_directory"]) == "" {
		acmeConfig["data_directory"] = "__GULPO_ACME_DATA_DIR__"
	}
}

func composeClientPassword(method, serverPassword, userPassword string) string {
	if strings.HasPrefix(method, "2022-blake3-") && serverPassword != "" {
		return serverPassword + ":" + userPassword
	}
	return userPassword
}

func buildSSURI(method, password, server string, port int, name string) string {
	credential := base64.RawURLEncoding.EncodeToString([]byte(method + ":" + password))
	return fmt.Sprintf("ss://%s@%s:%d#%s", credential, server, port, url.QueryEscape(name))
}

func normalizeServer(domain string) string {
	if host, _, err := net.SplitHostPort(domain); err == nil {
		return host
	}
	return domain
}

func maskSecret(secret string) string {
	if len(secret) <= 8 {
		return strings.Repeat("*", len(secret))
	}
	return secret[:4] + strings.Repeat("*", len(secret)-8) + secret[len(secret)-4:]
}

func durationInterval(value time.Duration) string {
	seconds := int(value / time.Second)
	if seconds < 1 {
		seconds = 1
	}
	return fmt.Sprintf("%d seconds", seconds)
}

func cloneMap(src map[string]any) map[string]any {
	out := make(map[string]any, len(src))
	for k, v := range src {
		switch nested := v.(type) {
		case map[string]any:
			out[k] = cloneMap(nested)
		case []any:
			copied := make([]any, len(nested))
			for i, item := range nested {
				if nestedMap, ok := item.(map[string]any); ok {
					copied[i] = cloneMap(nestedMap)
				} else {
					copied[i] = item
				}
			}
			out[k] = copied
		default:
			out[k] = v
		}
	}
	return out
}

func mergeMap(base, overlay map[string]any) map[string]any {
	for key, value := range overlay {
		if nestedOverlay, ok := value.(map[string]any); ok {
			if nestedBase, ok := base[key].(map[string]any); ok {
				base[key] = mergeMap(nestedBase, nestedOverlay)
				continue
			}
		}
		base[key] = value
	}
	return base
}

const schemaSQL = `
create table if not exists admins (
	id text primary key,
	email text not null unique,
	password_hash text not null,
	created_at timestamptz not null
);

create table if not exists users (
	id text primary key,
	external_id text,
	name text not null,
	status text not null,
	traffic_limit_bytes bigint not null default 0,
	traffic_used_bytes bigint not null default 0,
	subscription_token text not null unique,
	node_access_mode text not null,
	ss_password_encrypted text not null default '',
	trojan_password_encrypted text not null default '',
	created_at timestamptz not null,
	updated_at timestamptz not null
);

alter table users add column if not exists ss_password_encrypted text not null default '';
alter table users add column if not exists trojan_password_encrypted text not null default '';

create table if not exists tags (
	id text primary key,
	name text not null unique,
	created_at timestamptz not null
);

create table if not exists user_tags (
	user_id text not null references users(id) on delete cascade,
	tag_id text not null references tags(id) on delete cascade,
	primary key (user_id, tag_id)
);

create table if not exists nodes (
	id text primary key,
	name text not null,
	domain text not null,
	status text not null,
	default_access_policy text not null,
	default_access_tag text,
	enroll_token text not null unique,
	api_key text not null unique,
	agent_version text not null default '',
	singbox_version text not null default '',
	last_seen_at timestamptz,
	config_override jsonb not null default '{}'::jsonb,
	created_at timestamptz not null,
	updated_at timestamptz not null
);

create table if not exists user_node_access (
	user_id text not null references users(id) on delete cascade,
	node_id text not null references nodes(id) on delete cascade,
	primary key (user_id, node_id)
);

create table if not exists node_commands (
	id text primary key,
	node_id text not null references nodes(id) on delete cascade,
	type text not null,
	payload jsonb not null default '{}'::jsonb,
	status text not null,
	result text,
	issued_at timestamptz not null,
	applied_at timestamptz
);

create table if not exists global_config (
	id text primary key,
	config_json jsonb not null,
	updated_at timestamptz not null
);

create table if not exists usage_records (
	id text primary key,
	node_id text not null references nodes(id) on delete cascade,
	user_id text not null references users(id) on delete cascade,
	uplink_bytes bigint not null default 0,
	downlink_bytes bigint not null default 0,
	collected_at timestamptz not null
);

create table if not exists node_events (
	id text primary key,
	node_id text not null references nodes(id) on delete cascade,
	level text not null,
	type text not null,
	message text not null default '',
	source text not null,
	created_at timestamptz not null
);

create index if not exists idx_node_events_node_created_at on node_events (node_id, created_at desc);
`
